        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <?php $__env->startSection('content'); ?>

        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Paid List</h4>
                    </div>

                    <div class="col-7 align-self-center">
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Paid List</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <?php if(session()->has('message')): ?>
            <?php if(session()->get('message')=='existed'): ?>
                <div class="alert alert-danger">
                    <p>These values are exist</p>

                </div>
            <?php elseif(session()->get('message')=='deleted'): ?>
                <div class="alert alert-danger">
                    <p>Successfully deleted</p>

                </div>
            <?php elseif(session()->get('message')=='inserted'): ?>
                <div class="alert alert-success">
                    <p>Successfully Added</p>

                </div>
            <?php elseif(session()->get('message')=='existed'): ?>
                <div class="alert alert-success">
                    <p>Successfully Added</p>

                </div>
            <?php elseif(session()->get('message')=='updated'): ?>
                <div class="alert alert-success">
                    <p>Successfully Updated</p>

                </div>
            <?php endif; ?>
        <?php endif; ?>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                      <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </ul>
               </div>
               <?php endif; ?>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">




                <div class="row">
                    <!-- column -->
                    <div class="col-12   m-auto">
                        <div class="card">
                            <div class="table-responsive">
                                <table id="datatable" class="table table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0 text-center">S.L.</th>
                                            <th class="border-top-0 text-center">Client Type</th>
                                            <th class="border-top-0 text-center">Client Name</th>
                                            <th class="border-top-0 text-center">Project Name</th>
                                            <th class="border-top-0 text-center">Invoice Details</th>
                                            <th class="border-top-0 text-center">Total Time</th>
                                            <th class="border-top-0 text-center">Rate Per hour</th>
                                            <th class="border-top-0 text-center">Total Rate</th>
                                            <th class="border-top-0 text-center">Invoice Status</th>
                                            <th class="border-top-0 text-center">Invoice Date</th>
                                            <th class="border-top-0 text-center">Invoice Alert Date </th>
                                            <th class="border-top-0 text-center">Paid Date </th>
                                            <th class="border-top-0 text-center">Attachment </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php for($i=0;$i<$num;$i++): ?>
                                        <tr>

                                            <td style='text-align: center'><?php echo e($i+1); ?>

                                            </td>
                                            <?php for($j=0;$j<$num2+2;$j++): ?>
                                                <?php if($j==0): ?>
                                                <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?></td>
                                                <?php elseif($j==1): ?>
                                                <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?></td>
                                                <?php elseif($j==2): ?>
                                                <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?></td>
                                                <?php elseif($j==3): ?>
                                                <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?></td>
                                                <?php elseif($j==4): ?>
                                                <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?></td>
                                                <?php elseif($j==5): ?>
                                                <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?></td>
                                                <?php elseif($j==6): ?>
                                                <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?></td>
                                                <?php elseif($j==7): ?>
                                                <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?></td>
                                                <?php elseif($j==8): ?>
                                                <td style='text-align: center'><?php echo e(date('d/m/Y',strtotime($temp_array2[$i][$j]))); ?></td>
                                                <?php elseif($j==9): ?>
                                                <td style='text-align: center'><?php echo e(date('d/m/Y',strtotime($temp_array2[$i][$j]))); ?></td>
                                                <?php elseif($j==10): ?>
                                                <td style='text-align: center'><?php echo e(date('d/m/Y',strtotime( $temp_array2[$i][$j]))); ?></td>
                                                <?php elseif($j==11): ?>
                                                <td style='text-align: center'> <a target="_nobir" href="../storage/images/<?php echo e($temp_array2[$i][$j]); ?> "><?php echo e($temp_array2[$i][$j]); ?> </a></td>

                                                <?php endif; ?>


                                            
                                            <?php endfor; ?>
                                            

                                        </tr>
                                        <?php endfor; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                







            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center">
                All Rights Reserved by
                <a target="_nobir" href="https://www.euitsols.com">European IT Solutions</a>
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>

        <?php $__env->stopSection(); ?>


        <?php $__env->startSection('javaScript'); ?>
        <script>



$('#c_type').change(function(){
    $('#client_name').removeAttr("disabled");
    var client_type_id = $(this).val();
                if(client_type_id!="first"){
                    $.ajaxSetup({
                        headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                    });
                    $.ajax({
                        type: "GET",
                        dataType: 'json',
                        url: "client_info_ajax/"+client_type_id,
                        success:function(respose){
                            console.log(respose);
                            var data = '<option value="">Select Client Name</option>';
                            $.each(respose,function(key,value){
                                data = data + '<option value="'+value.id+'">'+value.c_name+'</option>';

                            });
                            $('#client_name').html(data);
                        }
                    });
                }
    });


$('#client_name').change(function(){
    // $('#client_name').removeAttr("disabled");
    var c_id = $(this).val();
                if(c_id!="first"){
                    $.ajaxSetup({
                        headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                    });
                    // $.ajax({
                    //     type: "GET",
                    //     dataType: 'json',
                    //     url: "client_info_ajax/"+c_id,
                    //     success:function(respose){
                    //         console.log(respose);
                    //         var data = '<option value="">Select Client Name</option>';
                    //         $.each(respose,function(key,value){
                    //             data = data + '<option value="'+value.id+'">'+value.c_name+'</option>';

                    //         });
                    //         $('#client_name').html(data);
                    //     }
                    // });
                }
    });


        </script>

        <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Framwork\Laravel\invoice\resources\views/invoice_paid_list.blade.php ENDPATH**/ ?>