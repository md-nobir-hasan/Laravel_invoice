<?php $__env->startSection('title'); ?>
  <title>Dashboard</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-5 align-self-center">
                <h4 class="page-title">Dashboard</h4>
                </div>

            <div class="col-7 align-self-center">
                <div class="d-flex align-items-center justify-content-end">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="#">Home</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Dashboard </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    

    <div class="container-fluid" style="background: #f2f4f5">
        
        <div class="toggle-section">
            <div class="nav nav-tabs" id="nav-tab" role="tablist">
              <button class="custom_tab nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">All Invoices</button>
              <button class="custom_tab nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Pending List</button>
              <button class="custom_tab nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Paid List</button>
              
              <?php $__currentLoopData = $client_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="custom_tab nav-link" data-bs-toggle="tab" type="button"><?php echo e($data->client_type_name); ?></button>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="tab-content" id="nav-tabContent">
            
            <div class="tab-pane fade show active" id="nav-home" role="tabpanel"   aria-labelledby="nav-home-tab">
                <div class="table-section bg-white p-5 rounded rounded-3 shadow bg-body">
                    
                    <div class="table-responsive">
                        <table id="datatable" class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th class="border-top-0 text-center">S.L.</th>
                                    <th class="border-top-0 text-center">Client Type</th>
                                    <th class="border-top-0 text-center">Client Name</th>
                                    <th class="border-top-0 text-center">Project Name</th>
                                    <th class="border-top-0 text-center">Invoice Details</th>
                                    <th class="border-top-0 text-center">Total Time</th>
                                    <th class="border-top-0 text-center">Rate Per hour</th>
                                    <th class="border-top-0 text-center">Total Rate</th>
                                    <th class="border-top-0 text-center">Invoice status</th>
                                    <th class="border-top-0 text-center">Invoice  Date</th>
                                    <th class="border-top-0 text-center">Invoice Alert Date</th>
                                    <th class="border-top-0 text-center">Attachment</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php for($i=0;$i<$num;$i++): ?>
                                    <tr>
                                        <td style='text-align: center'><?php echo e($i+1); ?>

                                        </td>
                                        <?php for($j=0;$j<$col_num;$j++): ?>
                                            <?php if($j==-1): ?>
                                            <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?>

                                            </td>
                                            <?php elseif($j==0): ?>
                                            <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?>

                                            </td>
                                            <?php elseif($j==1): ?>
                                            <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?>

                                            </td>
                                            <?php elseif($j==2): ?>
                                            <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?>

                                            </td>
                                            <?php elseif($j==3): ?>
                                            <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?>

                                            </td>
                                            <?php elseif($j==4): ?>
                                            <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?>

                                            </td>
                                            <?php elseif($j==5): ?>
                                            <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?>

                                            </td>
                                            <?php elseif($j==6): ?>
                                            <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?>

                                            </td>
                                            <?php elseif($j==7): ?>
                                            <td style='text-align: center'><?php echo e($temp_array2[$i][$j]); ?>

                                            </td>
                                            <?php elseif($j==8): ?>
                                            <td style='text-align: center'>

                                                <?php echo e(date('d/t/Y',strtotime($temp_array2[$i][$j]))); ?>

                                            </td>
                                            <?php elseif($j==9): ?>
                                            <td style='text-align: center'>

                                                <?php echo e(date('d/m/Y',strtotime($temp_array2[$i][$j]))); ?>

                                            </td>
                                            <td style='text-align: center'>
                                                <a target="_nobir" href="../storage/images/<?php echo e($temp_array2[$i][11]); ?>"><?php echo e($temp_array2[$i][11]); ?></a>
                                            </td>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </tr>
                                <?php endfor; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        

            
            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
            <div class="table-section bg-white p-5 rounded rounded-3 shadow bg-body">
                <div class="table-responsive">
                    <table id="datatable" class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <th class="border-top-0 text-center">S.L.</th>
                                <th class="border-top-0 text-center">Client Type</th>
                                <th class="border-top-0 text-center">Client Name</th>
                                <th class="border-top-0 text-center">Project Name</th>
                                <th class="border-top-0 text-center">Invoice Details</th>
                                <th class="border-top-0 text-center">Total Time</th>
                                <th class="border-top-0 text-center">Rate Per hour</th>
                                <th class="border-top-0 text-center">Total Rate</th>
                                <th class="border-top-0 text-center">Invoice Status</th>
                                <th class="border-top-0 text-center">Invoice Date</th>
                                <th class="border-top-0 text-center">Invoice Alert Date </th>
                                <th class="border-top-0 text-center">Attachment</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php for($i=1;$i<$pending_list_row_count;$i++): ?>
                                <tr>

                                    <td style='text-align: center'><?php echo e($i+1); ?>

                                    </td>
                                    <?php for($j=0;$j<$col_num+1;$j++): ?>

                                        <?php if($j==0): ?>
                                        <td style='text-align: center'><?php echo e($pending_list[$i][$j]); ?> </td>
                                        <?php elseif($j==1): ?>
                                        <td style='text-align: center'><?php echo e($pending_list[$i][$j]); ?></td>
                                        <?php elseif($j==2): ?>
                                        <td style='text-align: center'><?php echo e($pending_list[$i][$j]); ?></td>
                                        <?php elseif($j==3): ?>
                                        <td style='text-align: center'><?php echo e($pending_list[$i][$j]); ?></td>
                                        <?php elseif($j==4): ?>
                                        <td style='text-align: center'><?php echo e($pending_list[$i][$j]); ?></td>
                                        <?php elseif($j==5): ?>
                                        <td style='text-align: center'><?php echo e($pending_list[$i][$j]); ?></td>
                                        <?php elseif($j==6): ?>
                                        <td style='text-align: center'><?php echo e($pending_list[$i][$j]); ?></td>
                                        <?php elseif($j==7): ?>
                                        <td style='text-align: center'><?php echo e($pending_list[$i][$j]); ?></td>
                                        <?php elseif($j==8): ?>
                                        <td style='text-align: center'><?php echo e(date('d/m/Y',strtotime($pending_list[$i][$j]))); ?></td>
                                        <?php elseif($j==9): ?>
                                        <td style='text-align: center'><?php echo e(date('d/m/Y',strtotime($pending_list[$i][$j]))); ?></td>
                                        <?php elseif($j==10): ?>
                                        <td style='text-align: center'>
                                            <a target="_nobir" href="../storage/images/<?php echo e($pending_list[$i][10]); ?> "><?php echo e($pending_list[$i][10]); ?></a>
                                        </td>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
            <div class="table-section bg-white p-5 rounded rounded-3 shadow bg-body">
                <div class="table-responsive">
                    <table id="datatable" class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <th class="border-top-0 text-center">S.L.</th>
                                <th class="border-top-0 text-center">Client Type</th>
                                <th class="border-top-0 text-center">Client Name</th>
                                <th class="border-top-0 text-center">Project Name</th>
                                <th class="border-top-0 text-center">Invoice Details</th>
                                <th class="border-top-0 text-center">Total Time</th>
                                <th class="border-top-0 text-center">Rate Per hour</th>
                                <th class="border-top-0 text-center">Total Rate</th>
                                <th class="border-top-0 text-center">Invoice Status</th>
                                <th class="border-top-0 text-center">Invoice Date</th>
                                <th class="border-top-0 text-center">Invoice Alert Date </th>
                                <th class="border-top-0 text-center">Paid Date </th>
                                <th class="border-top-0 text-center">Attachment </th>
                            </tr>
                        </thead>
                        <tbody>
                        
                            <?php for($i=1;$i<$paid_list_row_count;$i++): ?>
                                <tr>

                                    <td style='text-align: center'><?php echo e($i+1); ?>

                                    </td>
                                    <?php for($j=0;$j<$col_num+2;$j++): ?>
                                        <?php if($j==0): ?>
                                        <td style='text-align: center'><?php echo e($paid_list[$i][$j]); ?></td>
                                        <?php elseif($j==1): ?>
                                        <td style='text-align: center'><?php echo e($paid_list[$i][$j]); ?></td>
                                        <?php elseif($j==2): ?>
                                        <td style='text-align: center'><?php echo e($paid_list[$i][$j]); ?></td>
                                        <?php elseif($j==3): ?>
                                        <td style='text-align: center'><?php echo e($paid_list[$i][$j]); ?></td>
                                        <?php elseif($j==4): ?>
                                        <td style='text-align: center'><?php echo e($paid_list[$i][$j]); ?></td>
                                        <?php elseif($j==5): ?>
                                        <td style='text-align: center'><?php echo e($paid_list[$i][$j]); ?></td>
                                        <?php elseif($j==6): ?>
                                        <td style='text-align: center'><?php echo e($paid_list[$i][$j]); ?></td>
                                        <?php elseif($j==7): ?>
                                        <td style='text-align: center'><?php echo e($paid_list[$i][$j]); ?></td>
                                        <?php elseif($j==8): ?>
                                        <td style='text-align: center'><?php echo e(date('d/m/Y',strtotime($paid_list[$i][$j]))); ?></td>
                                        <?php elseif($j==9): ?>
                                        <td style='text-align: center'><?php echo e(date('d/m/Y',strtotime($paid_list[$i][$j]))); ?></td>
                                        <?php elseif($j==10): ?>
                                        <td style='text-align: center'><?php echo e(date('d/m/Y',strtotime( $paid_list[$i][$j]))); ?></td>
                                        <?php elseif($j==11): ?>
                                        <td style='text-align: center'> <a target="_nobir" href="../storage/images/<?php echo e($paid_list[$i][$j]); ?> "><?php echo e($paid_list[$i][$j]); ?> </a></td>

                                        <?php endif; ?>
                                    <?php endfor; ?> 
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </div>



        
        
        
        
        <div class="active table-section domain_table_show" style="display: none">
            <div class="row">      
                <div class="col-12   m-auto">
                    <div class="card">
                        <h4 style="padding: 10px 0px  10px 15px; font-weight: bold;text-align: center">Domain Invoice List </h4>
                        <div class="table-responsive table-section bg-white p-5 rounded rounded-3 shadow bg-body">
                            <table id="datatable-domain" class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th class="border-top-0 text-center">S.L.</th>
                                        <th class="border-top-0 text-center">Client Type</th>
                                        <th class="border-top-0 text-center">Client Name</th>
                                        <th class="border-top-0 text-center">Invoice Details</th>
                                        <th class="border-top-0 text-center">Total Time</th>
                                        <th class="border-top-0 text-center">Rate Per hour</th>
                                        <th class="border-top-0 text-center">Total Rate</th>
                                        <th class="border-top-0 text-center">Invoice Status</th>
                                        <th class="border-top-0 text-center">Invoice Date</th>
                                        <th class="border-top-0 text-center">Invoice Alert Date </th>
                                        <th class="border-top-0 text-center">Paid Date </th>
                                        <th class="border-top-0 text-center">Attachment </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $domain_invoice_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style='text-align: center'><?php echo e($loop->index+1); ?>

                                            </td>
                                            <td style='text-align: center'><?php echo e($data->client_type->client_type_name); ?></td>
                                            <td style='text-align: center'><?php echo e($data->client_info->c_name); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->invoice_details); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->time_quote_hour.":".$data->time_quote_min); ?>hrs</td>
                                            <td style=' text-align: center'><?php echo e($data->rate_per_hour); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->total_rate); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->invoice_status); ?></td>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->invoiceDate ))); ?></td>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->invoiceAlertDate))); ?></td>
                                            <?php if($data->invoice_status=="paid"): ?>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->updated_at))); ?></td>
                                            <?php else: ?>
                                            <td style=' text-align: center'>Yet not paid</td>
                                            <?php endif; ?>
                                            <td style=' text-align: center'>
                                                <a target="_nobir" href="../storage/images/<?php echo e($data->attachment); ?>"><?php echo e($data->attachment); ?></a>
                                                <?php echo e($data->rate_per_hour); ?>

                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        
        <div class="hosting_table_show active table-section" style="display: none">
            <div class="row">
                <div class="col-12 m-auto">
                    <div class="card">
                    <h4 style="padding: 10px 0px  10px 15px; font-weight: bold;text-align: center">Hosting Invoice List</h4>
                        <div class="table-responsive table-section bg-white p-5 rounded rounded-3 shadow bg-body">
                            <table id="datatable-hosting" class="table table-responsive table-hover table-bordered w-100">
                                <thead>
                                    <tr>
                                        <th class="border-top-0 text-center">S.L.</th>
                                        <th class="border-top-0 text-center">Client Type</th>
                                        <th class="border-top-0 text-center">Client Name</th>
                                        <th class="border-top-0 text-center">Invoice Details</th>
                                        <th class="border-top-0 text-center">Total Time</th>
                                        <th class="border-top-0 text-center">Rate Per hour</th>
                                        <th class="border-top-0 text-center">Total Rate</th>
                                        <th class="border-top-0 text-center">Invoice Status</th>
                                        <th class="border-top-0 text-center">Invoice Date</th>
                                        <th class="border-top-0 text-center">Invoice Alert Date </th>
                                        <th class="border-top-0 text-center">Paid Date </th>
                                        <th class="border-top-0 text-center">Attachment </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $hosting_invoice_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style='text-align: center'><?php echo e($loop->index+1); ?>

                                            </td>
                                            <td style='text-align: center'><?php echo e($data->client_type->client_type_name); ?></td>
                                            <td style='text-align: center'><?php echo e($data->client_info->c_name); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->invoice_details); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->time_quote_hour.":".$data->time_quote_min); ?>hrs</td>
                                            <td style=' text-align: center'><?php echo e($data->rate_per_hour); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->total_rate); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->invoice_status); ?></td>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->invoiceDate ))); ?></td>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->invoiceAlertDate))); ?></td>
                                            <?php if($data->invoice_status=="paid"): ?>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->updated_at))); ?></td>
                                            <?php else: ?>
                                            <td style=' text-align: center'>Yet not paid</td>
                                            <?php endif; ?>
                                            <td style=' text-align: center'>
                                                <a target="_nobir" href="../storage/images/<?php echo e($data->attachment); ?>"><?php echo e($data->attachment); ?></a>
                                                <?php echo e($data->rate_per_hour); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="dh_table_show active table-section" style="display: none">
            <div class="row">
                <div class="col-12 m-auto">
                    <div class="card">
                    <h4 style="padding: 10px 0px  10px 15px; font-weight: bold;text-align: center">Domain And Hosting Invoice List</h4>
                        <div class="table-responsive table-section bg-white p-5 rounded rounded-3 shadow bg-body">
                            <table id="datatable-hosting" class="table table-responsive table-hover table-bordered w-100">
                                <thead>
                                    <tr>
                                        <th class="border-top-0 text-center">S.L.</th>
                                        <th class="border-top-0 text-center">Client Type</th>
                                        <th class="border-top-0 text-center">Client Name</th>
                                        <th class="border-top-0 text-center">Invoice Details</th>
                                        <th class="border-top-0 text-center">Total Time</th>
                                        <th class="border-top-0 text-center">Rate Per hour</th>
                                        <th class="border-top-0 text-center">Total Rate</th>
                                        <th class="border-top-0 text-center">Invoice Status</th>
                                        <th class="border-top-0 text-center">Invoice Date</th>
                                        <th class="border-top-0 text-center">Invoice Alert Date </th>
                                        <th class="border-top-0 text-center">Paid Date </th>
                                        <th class="border-top-0 text-center">Attachment </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $dh_invoice_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style='text-align: center'><?php echo e($loop->index+1); ?>

                                            </td>
                                            <td style='text-align: center'><?php echo e($data->client_type->client_type_name); ?></td>
                                            <td style='text-align: center'><?php echo e($data->client_info->c_name); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->invoice_details); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->time_quote_hour.":".$data->time_quote_min); ?>hrs</td>
                                            <td style=' text-align: center'><?php echo e($data->rate_per_hour); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->total_rate); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->invoice_status); ?></td>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->invoiceDate ))); ?></td>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->invoiceAlertDate))); ?></td>
                                            <?php if($data->invoice_status=="paid"): ?>
                                                <td style='text-align: center'><?php echo e(date('d/m/Y',strtotime($data->updated_at))); ?></td>
                                            <?php else: ?>
                                                <td style='text-align: center'>Yet not paid</td>
                                            <?php endif; ?> 
                                            <td style=' text-align: center'>
                                                <a target="_nobir" href="../storage/images/<?php echo e($data->attachment); ?>"><?php echo e($data->attachment); ?></a>
                                                
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="project_table_show active table-section" style="display: none">
            <div class="row">
                <div class="col-12 m-auto">
                    <div class="card">
                    <h4 style="padding: 10px 0px  10px 15px; font-weight: bold;text-align: center">Project Invoice List</h4>
                        <div class="table-responsive table-section bg-white p-5 rounded rounded-3 shadow bg-body">
                            <table id="datatable-hosting" class="table table-responsive table-hover table-bordered w-100">
                                <thead>
                                    <tr>
                                        <th class="border-top-0 text-center">S.L.</th>
                                        <th class="border-top-0 text-center">Client Type</th>
                                        <th class="border-top-0 text-center">Client Name</th>
                                        <th class="border-top-0 text-center">Invoice Details</th>
                                        <th class="border-top-0 text-center">Total Time</th>
                                        <th class="border-top-0 text-center">Rate Per hour</th>
                                        <th class="border-top-0 text-center">Total Rate</th>
                                        <th class="border-top-0 text-center">Invoice Status</th>
                                        <th class="border-top-0 text-center">Invoice Date</th>
                                        <th class="border-top-0 text-center">Invoice Alert Date </th>
                                        <th class="border-top-0 text-center">Paid Date </th>
                                        <th class="border-top-0 text-center">Attachment </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $project_invoice_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style='text-align: center'><?php echo e($loop->index+1); ?>

                                            </td>
                                            <td style='text-align: center'><?php echo e($data->client_type->client_type_name); ?></td>
                                            <td style='text-align: center'><?php echo e($data->client_info->c_name); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->invoice_details); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->time_quote_hour.":".$data->time_quote_min); ?>hrs</td>
                                            <td style=' text-align: center'><?php echo e($data->rate_per_hour); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->total_rate); ?></td>
                                            <td style=' text-align: center'><?php echo e($data->invoice_status); ?></td>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->invoiceDate ))); ?></td>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->invoiceAlertDate))); ?></td>
                                            <?php if($data->invoice_status=="paid"): ?>
                                            <td style=' text-align: center'><?php echo e(date('d/m/Y',strtotime($data->updated_at))); ?></td>
                                            <?php else: ?>
                                            <td style=' text-align: center'>Yet not paid</td>
                                            <?php endif; ?> 
                                            <td style=' text-align: center'>
                                                <a target="_nobir" href="../storage/images/<?php echo e($data->attachment); ?>"><?php echo e($data->attachment); ?></a>
                                                <?php echo e($data->rate_per_hour); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <footer class="footer text-center">
            All Rights Reserved by
            <a target="_nobir" href="https://www.euitsols.com">European IT Solutions</a>
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection("javaScript"); ?>

    <script>
        $('.custom_tab').each(function(index){
                $(this).click(function(){
                   var project_name = $(this).text().toLowerCase();
                   if(project_name=='domain')
                   {
                    $(".domain_table_show").attr('style','display: show !important');
                    $(".hosting_table_show").attr('style','display: none !important');
                    $(".dh_table_show").attr('style','display: none !important');
                    $(".project_table_show").attr('style','display: none !important');
                    $("#nav-home").attr('style','display: none !important');
                    $("#nav-profile").attr('style','display: none !important');
                    $("#nav-contact").attr('style','display: none !important');
                   }
                   if(project_name=='hosting')
                   {
                    // console.log('this is hosting');
                    $(".domain_table_show").attr('style','display: none !important');
                    $(".hosting_table_show").attr('style','display: show !important');
                    $(".dh_table_show").attr('style','display: none !important');
                    $(".project_table_show").attr('style','display: none !important');
                    $("#nav-home").attr('style','display: none !important');
                    $("#nav-profile").attr('style','display: none !important');
                    $("#nav-contact").attr('style','display: none !important');
                   }
                   if(project_name=='domain and hosting')
                   {
                    $(".domain_table_show").attr('style','display: none !important');
                    $(".hosting_table_show").attr('style','display: none !important');
                    $(".dh_table_show").attr('style','display: show !important');
                    $(".project_table_show").attr('style','display: none !important');
                    $("#nav-home").attr('style','display: none !important');
                    $("#nav-profile").attr('style','display: none !important');
                    $("#nav-contact").attr('style','display: none !important');
                   }
                   if(project_name=='project')
                   {
                    // console.log('this is projecte');
                    $(".domain_table_show").attr('style','display: none !important');
                    $(".hosting_table_show").attr('style','display: none !important');
                    $(".dh_table_show").attr('style','display: none !important');
                    $(".project_table_show").attr('style','display: show !important');
                    $("#nav-home").attr('style','display: none !important');
                    $("#nav-profile").attr('style','display: none !important');
                    $("#nav-contact").attr('style','display: none !important');
                   }
                   if(project_name !='project' && project_name !='domain and hosting' && project_name !='hosting' && project_name !='domain'){
                    $("#nav-home").attr('style','display: show !important');
                    $("#nav-profile").attr('style','display: show !important');
                    $("#nav-contact").attr('style','display: show !important');
                    $(".domain_table_show").attr('style','display: none !important');
                    $(".hosting_table_show").attr('style','display: none !important');
                    $(".dh_table_show").attr('style','display: none !important');
                    $(".project_table_show").attr('style','display: none !important');
                   }
                });
            });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/customer/www/invoice.euitsols.com/public_html/resources/views/dashboard.blade.php ENDPATH**/ ?>