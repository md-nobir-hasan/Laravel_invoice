<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DomainAndHostingController extends Controller
{
    public function insert(){

    }
}
